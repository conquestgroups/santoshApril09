package com.katari.amq.listener;


import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class MyListener {

	@JmsListener(destination = "${destination.topic}",
			//this was also needed with the same name as the bean above
			containerFactory = "jsaFactory" )
	public void reciver(String msg) {
		System.out.println(msg);
	}
}
